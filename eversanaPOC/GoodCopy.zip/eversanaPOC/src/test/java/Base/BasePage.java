package Base;


public abstract class BasePage extends BaseTest{



}
