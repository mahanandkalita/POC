package Base;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.BeforeTest;

import java.awt.*;
import java.awt.event.KeyEvent;

public  class BaseTest
{

    //public WebDriver driver;

    //@BeforeTest

    //public void LaunchBrowser() throws InterruptedException, AWTException
    {

    }
}
